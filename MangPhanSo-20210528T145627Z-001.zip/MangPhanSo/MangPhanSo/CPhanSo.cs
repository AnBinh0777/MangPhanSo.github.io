﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MangPhanSo
{
    class CPhanSo
    {
        int[] Mauso;
        int[] Tuso;
        int SoPS;



        public CPhanSo(int sophanso)
        {
            Mauso = new int[10];

            Tuso = new int[10];
            SoPS = sophanso;

        }
        public void TaoMangNgauNhien(int sophanso)
        {
            Random r = new Random();
            SoPS = sophanso;
            for (int i = 0; i < sophanso; i++)
            {
                Mauso[i] = r.Next(100);
                Tuso[i] = r.Next(100);
                int Uoc = UCLN(Tuso[i], Mauso[i]);

                if (Uoc != 0)
                {
                    if (Uoc > 0)
                    {
                        Tuso[i] = Tuso[i] / Uoc;
                        Mauso[i] = Mauso[i] / Uoc;
                    }
                    else
                    {
                        Tuso[i] = Tuso[i] / (-Uoc);
                        Mauso[i] = Mauso[i] / (Uoc);
                    }
                }
                
            }
        }

        private int UCLN(int Tuso, int Mauso)
        {

            if (Tuso != 0)
            {
                if (Tuso > 0)
                {
                    while (Tuso != Mauso)
                    {
                        if (Tuso > Mauso) Tuso -= Mauso;
                        else Mauso -= Tuso;
                    }
                    return Tuso;
                }
                else
                {
                    Tuso = -Tuso;
                    while (Tuso != Mauso)
                    {
                        if (Tuso > Mauso) Tuso -= Mauso;
                        else Mauso -= Tuso;
                    }
                    return Tuso;
                }
            }
            else return 0;
        }
        public void TaoMangPSTangDan(int sophanso)
        {
            SoPS = sophanso;
            Random r = new Random();
            Mauso[0] = r.Next(100);
            if (Mauso[0] == 0) Mauso[0] = 1;
            Tuso[0] = r.Next(100);
            for (int i = 1; i <= sophanso; i++)
            {
                Tuso[i] = r.Next(100);
                Mauso[i] = r.Next(100-i);


            }
        }
        public void LonHon(int sophanso)
        {
            SoPS = sophanso;
            Random r = new Random();
            Mauso[0] = r.Next(100);
            if (Mauso[0] == 0) Mauso[0] = 1;
            Tuso[0] = r.Next(100);
            for (int i = 0; i < sophanso; i++)
            {
                Mauso[i] = r.Next(100);
                do
                {
                    Tuso[i] = r.Next(100);
                } while (Tuso[i] <= Mauso[i]);
                   


             }
            
        }



        public string XuatMang()
    {
        string r = "";
        for (int i = 0; i < SoPS; i++)
        {
                int Uoc = UCLN(Tuso[i], Mauso[i]);

                if (Uoc != 0)
                {
                    if (Uoc > 0)
                    {
                        Tuso[i] = Tuso[i] / Uoc;
                        Mauso[i] = Mauso[i] / Uoc;
                    }
                    else
                    {
                        Tuso[i] = Tuso[i] / (-Uoc);
                        Mauso[i] = Mauso[i] / (Uoc);
                    }
                }
                if (Mauso[i] == Tuso[i]||Mauso[i]==1)
                {
                    r += Tuso[i].ToString()+" ; ";
                }

                else
                {
                    r += Tuso[i].ToString() + " / " + Mauso[i].ToString() + " ; ";
                }
        }
        return r;
    }



    }
}
